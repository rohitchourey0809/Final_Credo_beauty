function navBar(){
    return `
    
            <div id="pinkline">UP TO 40% OFF FOR A LIMITED TIME. SHOP THE SALE details</div>
        <div id="blueline">FREE SHIPPING ON ALL ORDERS| details</div>
        <div id="whitline">
            <div id="left"><a href="">Stores & Services</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Rewards</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">ChatLive</a></div>
            <div id="medium"><a href="home.html"><img src="https://cdn.shopify.com/s/files/1/0637/6147/files/logo_556396e7-3386-4a9c-8dfc-b9250175595e.png?height=628&pad_color=ffffff&v=1523377568&width=1200" width="130px" height="70px"alt=""></a></div>
            <div id="right"><img src="https://www.freeiconspng.com/thumbs/search-icon-png/search-icon-png-1.png" width="50px" height="50px" alt=""></div>
       <input type="text" placeholder="search" id="searchbar" ><img id="aclogo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThRGcLNaorK4esT7jd4P_MfhhrzowqyTHRqA8Ku2vZW7KNrswJYoA0CcmhlTTPsWSQZ5I&usqp=CAU" width="30px" height="30px"alt="">
        <img id="aclogo" src="https://cdns.iconmonstr.com/wp-content/assets/preview/2018/240/iconmonstr-heart-thin.png" width="30px" height="30px" alt=""><a href="cart.html"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgJpV_Q-MKeIRt9KzLZInQCzygSyKaxNo09NtSfLFajfxK0VQfVtRbWcsWls8I58-Zbo4&usqp=CAU" id="aclogo" width="30px" height="30px" alt=""></a></div><hr>
        <div id="menu"><ul>
            <li><a href="">BestSellers</a></li>
            <li><a href="new.html">New</a></li>
            <li><a href="">Brands</a></li>
            <li><a href="skincare.html">Skincare</a></li>
            <li><a href="makeup.html">Makeup</a></li>
            <li><a href="makeup.html">Hair</a></li>
            <li><a href="">Bath & Body</a></li>
            <li> <a href="">Fragrance</a></li>
            <li><a href="">Gifts</a></li>
            <li><a href="">Sales</a></li>
            <li><a href="">Featured</a></li>
        </ul></div> <hr id="bottom">
        <div id="secondwhite"> FREE SHIPPING ON ALL ORDERS!</div>
       
    
    `
    
    }
    
    export default navBar;