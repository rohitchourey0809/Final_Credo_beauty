import navBar from "./navbar.js"
let nav = document.getElementById("navbar")
nav.innerHTML = navBar()